-- MySQL dump 10.13  Distrib 8.0.32, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: techtest_gki_development
-- ------------------------------------------------------
-- Server version	8.0.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `products` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `price` int DEFAULT NULL,
  `category_id` int DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `image_product` varchar(255) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  `deletedAt` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products`
--

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` VALUES (1,'Serenity Bloom',50000,1,'Lorem ipsum dolor sit amet consectetur adipisicing elit. Delectus veniam omnis voluptates voluptatem! Tenetur, ipsum?','/image-product/1.jpg',1,'2023-11-10 03:19:08','2023-11-10 03:19:08',NULL),(2,'Ethereal Elegance',40000,2,'Lorem ipsum dolor sit amet consectetur adipisicing elit. Delectus veniam omnis voluptates voluptatem! Tenetur, ipsum?','/image-product/2.jpeg',1,'2023-11-10 03:19:08','2023-11-10 03:19:08',NULL),(3,'Golden Enchantment',20000,1,'Lorem ipsum dolor sit amet consectetur adipisicing elit. Delectus veniam omnis voluptates voluptatem! Tenetur, ipsum?','/image-product/3.jpeg',1,'2023-11-10 03:19:08','2023-11-10 03:19:08',NULL),(4,'Whispering Petals',150000,3,'Lorem ipsum dolor sit amet consectetur adipisicing elit. Delectus veniam omnis voluptates voluptatem! Tenetur, ipsum?','/image-product/4.jpg',1,'2023-11-10 03:19:08','2023-11-10 03:19:08',NULL),(5,'Mystic Mirage',51000,1,'Lorem ipsum dolor sit amet consectetur adipisicing elit. Delectus veniam omnis voluptates voluptatem! Tenetur, ipsum?','/image-product/5.jpg',1,'2023-11-10 03:19:08','2023-11-10 03:19:08',NULL),(6,'Velvet Seduction',55000,5,'Lorem ipsum dolor sit amet consectetur adipisicing elit. Delectus veniam omnis voluptates voluptatem! Tenetur, ipsum?','/image-product/6.jpeg',1,'2023-11-10 03:19:08','2023-11-10 03:19:08',NULL),(7,'Crimson Aura',58000,1,'Lorem ipsum dolor sit amet consectetur adipisicing elit. Delectus veniam omnis voluptates voluptatem! Tenetur, ipsum?','/image-product/7.jpeg',1,'2023-11-10 03:19:08','2023-11-10 03:19:08',NULL),(8,'Infinite Allure',200000,2,'Lorem ipsum dolor sit amet consectetur adipisicing elit. Delectus veniam omnis voluptates voluptatem! Tenetur, ipsum?','/image-product/8.jpeg',1,'2023-11-10 03:19:08','2023-11-10 03:19:08',NULL),(9,'Twilight Serenade',21000,1,'Lorem ipsum dolor sit amet consectetur adipisicing elit. Delectus veniam omnis voluptates voluptatem! Tenetur, ipsum?','/image-product/9.jpg',1,'2023-11-10 03:19:08','2023-11-10 03:19:08',NULL),(10,'Opulent Obsession',250000,5,'Lorem ipsum dolor sit amet consectetur adipisicing elit. Delectus veniam omnis voluptates voluptatem! Tenetur, ipsum?','/image-product/10.jpg',1,'2023-11-10 03:19:08','2023-11-10 03:19:08',NULL),(11,'Midnight Whispers',230000,1,'Lorem ipsum dolor sit amet consectetur adipisicing elit. Delectus veniam omnis voluptates voluptatem! Tenetur, ipsum?','/image-product/11.jpeg',1,'2023-11-10 03:19:08','2023-11-10 03:19:08',NULL),(12,'Enchanted Embrace',120000,3,'Lorem ipsum dolor sit amet consectetur adipisicing elit. Delectus veniam omnis voluptates voluptatem! Tenetur, ipsum?','/image-product/12.jpeg',1,'2023-11-10 03:19:08','2023-11-10 03:19:08',NULL),(13,'Radiant Reverie',210000,2,'Lorem ipsum dolor sit amet consectetur adipisicing elit. Delectus veniam omnis voluptates voluptatem! Tenetur, ipsum?','/image-product/13.jpg',1,'2023-11-10 03:19:08','2023-11-10 03:19:08',NULL),(14,'Celestial Charm',190000,4,'Lorem ipsum dolor sit amet consectetur adipisicing elit. Delectus veniam omnis voluptates voluptatem! Tenetur, ipsum?','/image-product/14.jpg',1,'2023-11-10 03:19:08','2023-11-10 03:19:08',NULL),(15,'Sapphire Dreams',200000,6,'Lorem ipsum dolor sit amet consectetur adipisicing elit. Delectus veniam omnis voluptates voluptatem! Tenetur, ipsum?','/image-product/15.jpeg',1,'2023-11-10 03:19:08','2023-11-10 03:19:08',NULL),(16,'Aurora Breeze',140000,2,'Lorem ipsum dolor sit amet consectetur adipisicing elit. Delectus veniam omnis voluptates voluptatem! Tenetur, ipsum?','/image-product/16.jpeg',1,'2023-11-10 03:19:08','2023-11-10 03:19:08',NULL),(17,'Divine Euphoria',110000,5,'Lorem ipsum dolor sit amet consectetur adipisicing elit. Delectus veniam omnis voluptates voluptatem! Tenetur, ipsum?','/image-product/17.jpg',1,'2023-11-10 03:19:08','2023-11-10 03:19:08',NULL),(18,'Amber Embers',150000,3,'Lorem ipsum dolor sit amet consectetur adipisicing elit. Delectus veniam omnis voluptates voluptatem! Tenetur, ipsum?','/image-product/18.jpeg',1,'2023-11-10 03:19:08','2023-11-10 03:19:08',NULL),(19,'Lustrous Lullaby',50000,3,'Lorem ipsum dolor sit amet consectetur adipisicing elit. Delectus veniam omnis voluptates voluptatem! Tenetur, ipsum?','/image-product/19.jpeg',1,'2023-11-10 03:19:08','2023-11-10 03:19:08',NULL),(20,'Moonlit Melody',110000,1,'Lorem ipsum dolor sit amet consectetur adipisicing elit. Delectus veniam omnis voluptates voluptatem! Tenetur, ipsum?','/image-product/20.jpeg',1,'2023-11-10 03:19:08','2023-11-10 03:19:08',NULL),(21,'Ivory Illusion',120000,1,'Lorem ipsum dolor sit amet consectetur adipisicing elit. Delectus veniam omnis voluptates voluptatem! Tenetur, ipsum?','/image-product/21.jpeg',1,'2023-11-10 03:19:08','2023-11-10 03:19:08',NULL),(22,'Harmony Haven',20000,2,'Lorem ipsum dolor sit amet consectetur adipisicing elit. Delectus veniam omnis voluptates voluptatem! Tenetur, ipsum?','/image-product/22.jpeg',1,'2023-11-10 03:19:08','2023-11-10 03:19:08',NULL),(23,'Sublime Symphony',100000,3,'Lorem ipsum dolor sit amet consectetur adipisicing elit. Delectus veniam omnis voluptates voluptatem! Tenetur, ipsum?','/image-product/23.jpeg',1,'2023-11-10 03:19:08','2023-11-10 03:19:08',NULL),(24,'Cascading Clouds',96000,1,'Lorem ipsum dolor sit amet consectetur adipisicing elit. Delectus veniam omnis voluptates voluptatem! Tenetur, ipsum?','/image-product/24.jpeg',1,'2023-11-10 03:19:08','2023-11-10 03:19:08',NULL),(25,'Vivid Verve',90000,5,'Lorem ipsum dolor sit amet consectetur adipisicing elit. Delectus veniam omnis voluptates voluptatem! Tenetur, ipsum?','/image-product/25.jpeg',1,'2023-11-10 03:19:08','2023-11-10 03:19:08',NULL),(26,'Scarlet Spell',59000,4,'Lorem ipsum dolor sit amet consectetur adipisicing elit. Delectus veniam omnis voluptates voluptatem! Tenetur, ipsum?','/image-product/26.jpeg',1,'2023-11-10 03:19:08','2023-11-10 03:19:08',NULL),(27,'Whimsical Whispers',90000,5,'Lorem ipsum dolor sit amet consectetur adipisicing elit. Delectus veniam omnis voluptates voluptatem! Tenetur, ipsum?','/image-product/27.jpg',0,'2023-11-10 03:19:08','2023-11-10 03:19:08',NULL);
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-11-10 10:36:30
